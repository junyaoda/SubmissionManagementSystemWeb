<template>
    <v-footer dark app class="d-flex align-center justify-center">
        <div>
        Copyright © .... CO.,LTD. All right reserved
        </div>
    </v-footer>
</template>

<script>
</script>

<style scoped>
</style>